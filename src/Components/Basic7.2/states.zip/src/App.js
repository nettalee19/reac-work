import Basic from "./Components/Basic1.1/Basic";
import Aaa from "./Components/Boxes/Boxes";
import Somthing from './Components/Boxes/Boxes'
import ClassState from "./Components/states/ClassState";
import FunctionState from "./Components/states/FunctionState";


function App() {
    return (
        <div>
          <FunctionState/>
        </div>
    );
}


export default App;
