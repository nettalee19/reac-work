

import react from 'react';

class Test extends react.Component {
    constructor(props) {
        super();
    }

    render() {
        return <>

        </>
    }

};
module.exports = Test;
