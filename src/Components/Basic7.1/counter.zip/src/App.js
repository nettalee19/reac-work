import Counter from './components/counter/Counter'
import Counter2 from './components/counter/Counter2'

function App() {
    return (
        <div>
            Counter : <Counter/><br/>

        </div>
    );
}

export default App;
