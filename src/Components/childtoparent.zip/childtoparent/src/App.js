import Aba from './Parent'

function App() {
  return (
    <div>
<Aba/>
    </div>
  );
}

export default App;
