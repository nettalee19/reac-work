import react from 'react';

class Ben extends react.Component {
    constructor(props) {
        super(props);
        this.state = {
            removeNumber : 0
        }
    }

    textHandelr = (e)=>{
        this.setState({removeNumber : e.target.value})
    }

    btnSendUpLastDigit = () => {
        // this.props.getLast(this.state.removeNumber)
        this.props.test()
    }

    render() {
        return (
            <>
                <input type={'number'} value={this.state.removeNumber} onChange={this.textHandelr}/>
                <input type={'button'} value={'send to Aba'}
                       onClick={this.btnSendUpLastDigit}
                />
            </>
        )
    }
}

export default Ben;
