import react from 'react';
import Ben from './Ben'
class Parent extends react.Component {
    constructor(props) {
        super(props);
        this.state = {
            numbers : [5,8,43,9]
        }
    }

    benHandlerLastDigit = (data)=>{
        console.log(data)
        let newArr = this.state.numbers;//copy of the state
        newArr = newArr.filter((num)=>{
            return num != data
        })

        this.setState({numbers : newArr})

        console.log(newArr)
    }

    render() {
        return (
            <>
                <Ben getLast={this.benHandlerLastDigit}

                     test={()=>{
                         console.log('test')
                     }}
                />

                {this.state.numbers.map((u)=>{
                    return <div>{u}</div>
                })}


                </>
        )
    }
}

export default Parent;
