import Api from "./Api";

function App() {
    return (
        <div>
            <Api/>
        </div>
    );
}

export default App;
