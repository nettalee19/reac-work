import react from 'react';
import axios from 'axios';

export default class Api extends react.Component {
    constructor(props) {
        super(props);
        this.state = {
            users : []
        }
    }

    async componentDidMount() {
        // const data = await (await fetch('https://jsonplaceholder.typicode.com/users')).json()
        // console.log(data)

        // axios.get('https://jsonplaceholder.typicode.com/users')
        //     .then(function (response) {
        //         // handle success
        //         console.log(response.data);
        //     })
        //     .catch(function (error) {
        //         // handle error
        //         console.log(error);
        //     })

        const request = await axios.get('https://jsonplaceholder.typicode.com/users')
        console.log('data :',request.data)

        this.setState({users : request.data})
    }

    render() {
        return<>
            {
                this.state.users.map((u,index)=>{
                    return <div key={u.id}>name :{u.name} , email : {u.email}</div>
                })
            }
        </>
    }
}
