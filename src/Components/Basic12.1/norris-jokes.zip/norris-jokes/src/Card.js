import react from 'react';
import axios from "axios";

export default class Card extends react.Component {
    constructor(props) {
        super(props);
        this.props.joke = 'asfasf'
        this.state = {
            joke: this.props.joke,
            cat: this.props.cat,
            selectedCat: ''
        }
    }

    async componentDidUpdate(prevProps, prevState, snapshot) {

        // if (prevProps.joke !== this.props.joke) {
            await this.setState({joke: this.props.joke})
        }
        if (prevProps.cat.length !== this.props.cat.length) {
            await this.setState({cat: this.props.cat})
        }
    }

    getNewJoke = () => {
        this.props.renderJoke(this.state.selectedCat);
    }

    handlerDropDown = (e) => {
        console.log(e.target.value)
        this.setState({selectedCat: e.target.value})
    }

    render() {
        return <div className={'card'}>
            <div className={'card-title'}></div>
            <div className={'card-body'}>
                {this.state.joke}

                <select onChange={this.handlerDropDown}>
                    <option>All</option>
                    {
                        this.state.cat.map((c) => {
                            return <option>{c} </option>
                        })
                    }
                </select>
                <input type={'button'} value={'Get New Joke'} onClick={this.getNewJoke}/>
            </div>
            <div className={'card-footer'}></div>
        </div>
    }
}
