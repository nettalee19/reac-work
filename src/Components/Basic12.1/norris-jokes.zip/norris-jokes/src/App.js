import './App.css'
import Jokes from "./Jokes";

function App() {
  return (
    <div>
    <Jokes/>
    </div>
  );
}

export default App;
