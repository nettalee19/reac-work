import react from 'react';
import axios from "axios";
import Card from "./Card";

export default class Jokes extends react.Component {
    constructor(props) {
        super(props);
        this.state = {
            joke: '',
            cat : []
        }
    }

    async componentDidMount() {
        const request = await axios.get('https://api.chucknorris.io/jokes/random');
         const catReq = await axios.get('https://api.chucknorris.io/jokes/categories');

        console.log(request);


        this.setState({joke: request.data.value , cat : catReq.data })
    }

    getNewJoke = async(category)=>{
        console.log('category :',category)

        if(category === 'All'){
            const request = await axios.get('https://api.chucknorris.io/jokes/random');
            this.setState({joke: request.data.value })
        }
        else{
            const request = await axios.get(`https://api.chucknorris.io/jokes/random?category=${category}`);
            this.setState({joke: request.data.value })
        }

    }

    render() {
        return <>
           <Card renderJoke={this.getNewJoke} cat={this.state.cat} joke={this.state.joke}/>
        </>
    }
}
