import Basic from "./Components/Basic1.1/Basic";
import Aaa from "./Components/Boxes/Boxes";
import Somthing from './Components/Boxes/Boxes'
function App() {
    return (
        <div>
            {/*<Aaa/>*/}
            <Somthing/>
        </div>
    );
}


export default App;
