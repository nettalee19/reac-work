const arr = ["Hello","World"];

const Basic = ()=>{
    return <div>
        {
            arr.join(' ')
        }
    </div>
}

export default Basic;
