import Box1 from './Box1';
import './boxStyle.css';

const Boxies = ()=>{
    return <div>
        <Box1/>
    </div>
}

export default Boxies;
