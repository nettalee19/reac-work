import react from "react";
import axios from "axios";

const Countries = () => {
    const [countries, setCountries] = react.useState([])
    const [search, setSearch] = react.useState('')
    const getCountries = async () => {
        const req = await axios.get('https://restcountries.eu/rest/v2/all');
        setCountries(req.data)
    }

    react.useEffect(() => {
        getCountries();
    }, [])


    const textHandler = (e) => {
        setSearch(e.target.value)
    }

    const Getc = () => {
        return countries.filter((c) => {
            return c.name.toLowerCase().startsWith(search);
        }).map((c) => {
            return <div>{c.name}</div>
        })
    }

    return (
        <>
            <input type={'text'} value={search} onChange={textHandler}/>
            {/*{getc()}*/}

            <Getc/>
            {
                countries.map((c) => {
                    return <div>{c.name}</div>
                })
            }

        </>
    )
}

export default Countries;
