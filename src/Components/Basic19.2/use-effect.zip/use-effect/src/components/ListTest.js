import react from 'react';

const ListTest = () => {
    const [names, setNames] = react.useState(['name1', 'name2']);
    const [str, setStr] = react.useState('');

    react.useEffect(()=>{
        console.log("useEffect")
    },[])


    const textHandler = e => {
        setStr(e.target.value);
    }

    const addName = ()=>{
        let namesList = [...names]
        namesList.push(str)
        setNames(namesList)
        setStr('')
    }

    return (
        <>
            <input type={'text'} value={str} onChange={textHandler}/>
            <input type={'button'} value={'click'} onClick={addName}/>

            {
                names.map((n)=>{
                    return <div>{n}</div>
                })
            }
        </>
    )
}

export default ListTest;
