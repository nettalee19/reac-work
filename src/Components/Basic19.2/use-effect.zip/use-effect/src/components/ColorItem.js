import react from 'react';

const ColorItem = ({colorItem, deleteColor}) => {

    const [color, setColor] = react.useState(colorItem)


    // react.useEffect(() => {
    //     setColor(colorItem)
    // }, [colorItem])

    return (
        <div>
            {color}<input type={'button'} value={'delete'} onClick={() => {
            deleteColor(color)
        }}/>

        </div>
    )
}

export default ColorItem;

