import react from 'react';
import ColorItem from "./ColorItem";

const ColorList = () => {
    const [colorsList, setColorsList] = react.useState(['red','blue','yellow','green']);
    const [color, setColor] = react.useState('');

    const textHandler = (e)=>{
        // setColor(e.target.value)
    }

    const addColor = ()=>{
        let colorList = [...colorsList];
        colorList.push(color);
        setColorsList(colorList);
        setColor('')
    }

    const removeColor = (data)=>{
        let colors = colorsList.filter((c)=>{
            return c !== data;
        });

        setColorsList(colors)

    }

    return (
        <div>
            <input type={'text'} value={color} onChange={textHandler}/>
            <input type={'button'} value={'add'} onClick={addColor}/>

            {
                colorsList.map((item)=>{
                    return <ColorItem deleteColor={removeColor} colorItem={item}/>
                })
            }

        </div>
    )
}

export default ColorList;

