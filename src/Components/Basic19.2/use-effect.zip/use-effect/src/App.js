import Countries from "./components/countries/Countries";

function App() {
    return (
        <div>
        <Countries/>
        </div>
    );
}

export default App;
